/******************************************************************************
 Copyright (c) 2018 Flex(Shanghai) Co.,Ltd.
 All rights reserved.

 [Module Name]:
 		flex_framework_privtocol.c
 [Date]:
 		2018-08-14
 [Author]:
 		joanna Wang
 [Reversion History]:
 		v1.0
*******************************************************************************/
/*========================================================================================================
										I N C L U D E
========================================================================================================*/
#include <stdio.h>
#include <string.h>
#include "usart.h"
#include "flex_app_nvparam.h"
#include "flex_framework_privtocol.h"

/*========================================================================================================
										D E F I N E
========================================================================================================*/
#define NEW_LINE		"\r\n"
#define FREAME_HEADER		0xAA55
#define CMD_BEFORE_DATA_LEN	 5
#define CMD_POS		2
#define SUBCMD_POS	 3
#define CMDDATA_LEN_POS	 4

#define PRIVTOCOL_RX_BUFFERSIZE		1024
#define PRIVTOCOL_TX_TIMEOUT		(1000)
#define PRIVTOCOL_CMD_RSP_TIMEOUT	(4000)
#define PRIVTOCOL_TX_MSG_Q_SIZE		10
#define PRIVTOCOL_MAX_DATA_LEN		128

//debounce time in ms
#define DEBOUNCE_TIME	(50)

//rx task event notification bit field
#define RX_IDLE_EVENT				_BIT0_
#define RX_BUFFER_FULL_EVENT		_BIT1_
/*========================================================================================================
						F U N C T I ON Declaration
========================================================================================================*/
static void Privtocol_UartInit(void);
static void Privtocol_RxMsgAnalysis(char *message);
static void Privtocol_RxMsgCombination(char *message);
unsigned char crc_high_first(unsigned char *ptr, unsigned char len);
static osStatus Privtocol_TxMsgPut(osMessageQId queue_id, void *message, uint32_t millisec);


/*========================================================================================================
										E X T E R N
========================================================================================================*/
extern DMA_HandleTypeDef hdma_usart2_rx;
static osThreadId rxTaskHandle;
static osThreadId txTaskHandle;
static osMessageQId txMsgQId;
static osSemaphoreId cmdRspSemaphore;
static uint8_t rxBuffer[PRIVTOCOL_RX_BUFFERSIZE];
static uint8_t rxBufferCombination[PRIVTOCOL_RX_BUFFERSIZE];
/*========================================================================================================
										T Y P E D E F
========================================================================================================*/

typedef struct
{	
	const PRIVTOCOL_SUBCMD subcmd ;	
	bool ( * handler) (char *rx);
}PRIVTOCOL_RX_MSG_HANDLER;

typedef void (*Privtocol_TxFunc)(void *);
typedef struct
{
	Privtocol_TxFunc function;
	void *parameter;//parameter
}PRIVTOCOL_TX_MSG;

/*========================================================================================================
						F U N C T I ON Declaration
========================================================================================================*/

/*========================================================================================================
										V A R I A B L E S
========================================================================================================*/

/*========================================================================================================
										F U N C T I O N
========================================================================================================*/
static  PRIVTOCOL_RX_MSG_HANDLER const Info_HandlerTbl[] =
{ 
	{SUBCMD_GET_PROT_VER,Privtocol_Get_Communication_Protocol_Version},
	{SUBCMD_GET_DEVICE_ID,Privtocol_Get_Device_ID},
	{SUBCMD_SET_DEVICE_ID,Privtocol_Set_Device_ID}
};
static  PRIVTOCOL_RX_MSG_HANDLER const Ctl_HandlerTbl[] =
{ 
	{SUBCMD_SET_LCD,Privtocol_Control_Lcd},
	{SUBCMD_SET_WIRELESS,Privtocol_Control_Wireless},
	{SUBCMD_SET_BEEPER,Privtocol_Control_Beeper},
	{SUBCMD_SET_TIME,Privtocol_Control_Time},
	{SUBCMD_SET_LED,Privtocol_Control_Led},	
};
static  PRIVTOCOL_RX_MSG_HANDLER const Stus_HandlerTbl[] =
{ 
	{SUBCMD_GET_LCD,Privtocol_Get_Lcd_Status},
	{SUBCMD_GET_WIRELESS,Privtocol_Get_Wireless_Status},
	{SUBCMD_GET_BEEPER,Privtocol_Get_Beeper_Status},
	{SUBCMD_GET_TIME,Privtocol_Get_Time_Status},
	{SUBCMD_GET_LED,Privtocol_Get_Led_Status},	
};

/*!
*\brief  UART received message CRC8
*/
unsigned char crc_high_first(unsigned char *ptr, unsigned char len)
{
    unsigned char i; 
    unsigned char crc=0x00;  

    while(len--)
    {
        crc ^= *ptr++;    
        for (i=8; i>0; --i)  
        { 
            if (crc & 0x80)
                crc = (crc << 1) ^ 0x31;
            else
                crc = (crc << 1);
        }
    }

    return (crc); 
}
/*!
*\brief  UART received message combination
*/
static void Privtocol_RxMsgCombination(char *message)
{
	strcat((char*)rxBufferCombination,message);
	DBG_MSG("rxBufferCombination��%s", rxBufferCombination);	
}

/*!
*\brief  UART received message processor
*/
static void Privtocol_RxMsgProcessor(char *message)
{
	
}
/*!
*\brief  UART received message Analysis
*/
static void Privtocol_RxMsgAnalysis(char *message)
{
	uint8_t i=0;
	uint8_t datalen = 0;
	uint8_t crc8_value = 0;

////	if((strlen(message) < CMD_BEFORE_DATA_LEN)&&(strlen((char*)rxBufferCombination) < CMD_BEFORE_DATA_LEN))
////	{
////		DBG_MSG("%d %d \r\n", strlen(message),strlen((char*)rxBufferCombination));
////		Privtocol_RxMsgCombination(message);
////	}
////	else if(CMD_BEFORE_DATA_LEN < strlen((char*)rxBufferCombination) < CMD_BEFORE_DATA_LEN + 1 + rxBufferCombination[CMDDATA_LEN_POS])
////	{
////		DBG_MSG("%d\r\n", rxBufferCombination[CMDDATA_LEN_POS]);
////		Privtocol_RxMsgCombination(message);
////	}
	do
	{
		if(message)
		{
			datalen = message[CMDDATA_LEN_POS];
			crc8_value = message[CMDDATA_LEN_POS + datalen + 1];
			if(crc_high_first((unsigned char *)message, strlen(message)) == crc8_value)
			{
				Privtocol_RxMsgProcessor(message);//TBD call function
			}
			else
			{
				DBG_MSG("CRC8 error\r\n");
				Privtocol_RxMsgCombination(message);
			}
		}
	}while(message[i] != '\0');
}
/*!
*\brief  UART initialization for private protocol communication
*/
static void Privtocol_UartInit(void)
{

	//Enable UART RX DMA
	pf_memset(rxBuffer, 0, PRIVTOCOL_RX_BUFFERSIZE);
	HAL_UART_Receive_DMA(&huart2, rxBuffer, PRIVTOCOL_RX_BUFFERSIZE);

	//enable RX line idle interrupt
	__HAL_UART_ENABLE_IT(&huart2, UART_IT_IDLE);
}

/*!
*\brief  UART RX line idle interrupt handler
*/
void Privtocol_UartRxIdleHandler(void)
{
	__HAL_UART_CLEAR_IDLEFLAG(&huart2);

	if (rxTaskHandle)
	{
		uint16_t size =  PRIVTOCOL_RX_BUFFERSIZE - __HAL_DMA_GET_COUNTER(&hdma_usart2_rx);

		if (size)
		{
			osSignalSet(rxTaskHandle, RX_IDLE_EVENT);
		}
	}
}


/*!
*\brief  UART received message dispatcher
*/
static void Privtocol_RxMsgDispatcher(void)
{
	uint16_t i;
	char *start;
	char *end;
	uint16_t remain;
	uint16_t rxSize;
	uint16_t items;
	const PRIVTOCOL_RX_MSG_HANDLER *handlerPtr;
	
	//stop UART RX DMA
	HAL_UART_DMAStop(&huart2);
	//recieved size
	rxSize =  PRIVTOCOL_RX_BUFFERSIZE - __HAL_DMA_GET_COUNTER(&hdma_usart2_rx);
	//DBG_MSG("%s", rxBuffer);
  Privtocol_RxMsgAnalysis((char *)rxBuffer);//Privtocol_RxMsgCombination((char *)rxBuffer);	
	memset(rxBuffer, 0, rxSize);
	rxSize = 0;
	HAL_UART_Receive_DMA(&huart2, (uint8_t *)rxBuffer, PRIVTOCOL_RX_BUFFERSIZE);
	if (PRIVTOCOL_RX_BUFFERSIZE <= rxSize)
	{
		DBG_MSG("Warning:ESP32 UART DMA Rx Buffer Full:%d\n", PRIVTOCOL_RX_BUFFERSIZE);
		//Todo: need to handle DMA Rx buffer full situation further
	}

//	start = (char *)rxBuffer;

//	do
//	{
//		//
//		//Process message line by line (line with "\r\n")
//		//

//		//find new line by searching "\r\n"
//		end = strstr(start, NEW_LINE);

//		if (end)
//		{
//			//replace with terminator '\0' to construct a string
//			*end = '\0';

//			DBG_MSG("%s\r\n", start);

//			//skip blank line ("\r\n")
//			if (strlen(start))
//			{

////				if ('+' == start[0])
////				{
////					//handlers for message with prefix '+'
////					handlerPtr = rxMsgHandlerTbl1;
////					items = sizeof(rxMsgHandlerTbl1) / sizeof(PRIVTOCOL_RX_MSG_HANDLER);
////				}
////				else
////				{
////					handlerPtr = rxMsgHandlerTbl2;
////					items = sizeof(rxMsgHandlerTbl2) / sizeof(PRIVTOCOL_RX_MSG_HANDLER);
////				}

////				//walk through table to search message handler
////				for ( i = 0 ; i < items; i++)
////				{
////					if (strstr((const char * )start, handlerPtr[i].message))
////					{
////						if (handlerPtr[i].handler((char *)start))
////						{
////							//message has been proceeded, move forward
////							break;
////						}
////					}
////				}
//			}

//			//move to next line
//			start = end + strlen(NEW_LINE);
//		}
//	}
//	while (end);


//	/*Tim.Lin: copy remaining characters to buffer head.for instance:
//	   RX: WIFI CONNECTED\r\nWIFI GOT -- rx line idle event
//	   RX: IP\r\n - rx line idle event
//	   After proceeding "WIFI CONNECTED\r\n", WIFI GOT shall be kept instead of discard,
//	   move "WIFI GOT" to start of rx buffer and DMA Rx from end of "WIFI GOT"
//	*/

//	//check remaining characters
//	remain = strlen(start);

//	if (remain)
//	{
//		//skip copy if start is in begining of rx buffer
//		if (start != (char *)rxBuffer)
//		{
//			strncpy((char *)rxBuffer, start, remain);
//		}
//	}

//	//check if clear is needed
//	if (rxSize - remain)
//	{
//		pf_memset(&rxBuffer[remain], 0, rxSize - remain);
//	}

//	//start UART recived DMA
//	HAL_UART_Receive_DMA(&huart2, (uint8_t *)&rxBuffer[remain], PRIVTOCOL_RX_BUFFERSIZE - remain);
}
/*!
*\brief Private protocol receiver task
*\param [in] argument - argument pointer
*/
void Privtocol_RxTask(void const *argument)
{
	osEvent event;
	rxTaskHandle = osThreadGetId();

	/* Infinite loop */
	for (;;)
	{
		event = osSignalWait(0x7FFFFFFF, osWaitForever);

		if (event.status == osEventSignal)
		{
			if (event.value.signals & RX_IDLE_EVENT)
			{
				Privtocol_RxMsgDispatcher();
			}

			if (event.value.signals & RX_BUFFER_FULL_EVENT)
			{
				DBG_MSG("Warning: ESP32 UART DMA Rx Buffer Full:%d\n", PRIVTOCOL_RX_BUFFERSIZE);
				//Todo: need to handle DMA Rx buffer full situation
			}
		}
	}
}


/*!
*\brief ESP32 transmit task
*\param [in] argument - argument pointer
*/
void Privtocol_TxTask(void const *argument)
{
	osEvent event;
	PRIVTOCOL_TX_MSG *pTxMsg;

	txTaskHandle = osThreadGetId();

	osSemaphoreDef(esp32CmdRspSem);
	cmdRspSemaphore = osSemaphoreCreate (osSemaphore(esp32CmdRspSem), 1);
	assert_param(cmdRspSemaphore != NULL);

	osMessageQDef(esp32TxMsgQ, PRIVTOCOL_TX_MSG_Q_SIZE, PRIVTOCOL_TX_MSG);
	txMsgQId = osMessageCreate (osMessageQ(esp32TxMsgQ), txTaskHandle);
	assert_param(txMsgQId != NULL);

	//intialize UART
	Privtocol_UartInit();

	/* Infinite loop */
	for (;;)
	{
		event = osMessageGet(txMsgQId, portMAX_DELAY);

		if (event.status == osEventMessage)
		{
			pTxMsg = (PRIVTOCOL_TX_MSG *)&event.value;

			if (pTxMsg->function)
			{
				pTxMsg->function(pTxMsg->parameter);
			}
		}
	}
}
/*!
*\brief Private protocol initialization function
*/
void Privtocol_Init(void)
{
	osThreadDef(PrivtocolRxTask, Privtocol_RxTask, osPriorityBelowNormal, 0, 128);
	osThreadCreate(osThread(PrivtocolRxTask), NULL);

	osThreadDef(PrivtocolTxTask, Privtocol_TxTask, osPriorityLow, 0, 128);
	osThreadCreate(osThread(PrivtocolTxTask), NULL);
}
